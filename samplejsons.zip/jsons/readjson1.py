


import json

fobj = open("example_1.json","r")

data = json.load(fobj)

print(data)


fobj.close()